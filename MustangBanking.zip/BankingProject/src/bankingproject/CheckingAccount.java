
package bankingproject;

/**
 *
 * @author Tony Lim
 */
public class CheckingAccount extends Account
{
    
    public CheckingAccount(int Id, double InterestRate, Balance Balance) 
    {
        super(Id, InterestRate, Balance);
    }
    
    public void xWriteCheck(int Id)
    {
        //WriteCheck
    }
    
    
    
}
