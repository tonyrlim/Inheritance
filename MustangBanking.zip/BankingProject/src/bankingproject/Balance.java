/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankingproject;

/**
 *
 * @author Tony Lim
 */
public class Balance 
{
    private double dBalance;
    public Balance()
    {
        dBalance = 0;
    }
    
    public Balance(double setToBalance)
    {
        dBalance = setToBalance;
    }
    
    public double getBalance()
    {
        return dBalance;
    }
    
    public void setBalance(double setToBalance)
    {
        dBalance = setToBalance;
    }
    
}
