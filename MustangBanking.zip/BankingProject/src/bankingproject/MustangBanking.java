
package bankingproject;

import java.util.ArrayList;
import java.util.*;
import java.io.*;
/**
 *
 * @author Tony Lim
 */
public class MustangBanking 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        MustangBanking bank = new MustangBanking();
        ArrayList<Account> accounts = new ArrayList<Account>();
        System.out.println("Welcome to your Mustang Bank!");
        int selection;
        do{
        System.out.println("Please choose from the following options: \n" +
                           "  1 - Create a new Checking Account\n" +
                           "  2 - Create a new Savings Account\n" +
                           "  3 - Delete an existing account\n" +
                           "  4 - View a specific account\n" +
                           "  5 - View all accounts\n" +
                           "  6 - Write a check through a specific Checking Account\n" +
                           "  7 - Withdraw funds from a specific account\n" + 
                           "  8 - Deposit funds into an account\n" +
                           "  9 - Exit Program\n"
                          );
        
        System.out.println("Please enter your option below: \n");
        selection = input.nextInt();
        input.nextLine();
        
        switch(selection)
        {
            case 1:
                System.out.println("Please enter your ID: ");
                int iD = input.nextInt();
                System.out.println("Please enter your given interest rate: ");
                double intRate = input.nextDouble();
                System.out.println("Please enter an opening balance: ");
                double bal = input.nextDouble();
                Balance balance = new Balance(bal);
                bank.xCreateChecking(accounts, iD, intRate, balance);
                break;
            case 2:
                System.out.println("Please enter your ID: ");
                int iDSaving = input.nextInt();
                System.out.println("Please enter your given interest rate: ");
                double intRateSaving = input.nextDouble();
                System.out.println("Please enter an opening balance: ");
                double balSaving = input.nextDouble();
                Balance balanceSaving = new Balance(balSaving);
                bank.xCreateSavings(accounts, iDSaving, intRateSaving, balanceSaving);
                break;
            case 3:
                System.out.println("Please enter the ID of the account you wish to delete: ");
                int deleteID = input.nextInt();
                bank.xDeleteAccount(accounts, deleteID);
                break;
            case 4:
                System.out.println("Please enter the ID of the specific account you wish to see: ");
                int viewID = input.nextInt();
                bank.xViewSpecific(accounts, viewID);
                break;
            case 5:
                bank.xViewAll(accounts);
                break;
            case 6:
                System.out.println("Please enter the ID of the specific account you wish to write a check from: ");
                int checkID = input.nextInt();
                bank.xWriteCheck(accounts, checkID);
                break;
            case 7:
                System.out.println("Please enter the ID of the specific account you wish to withdraw from: ");
                int withdrawID = input.nextInt();
                bank.xWithdraw(accounts, withdrawID);
                break;
            case 8:
                System.out.println("Please enter the ID of the specific account you wish to deposit to: ");
                int depositID = input.nextInt();
                bank.xDeposit(accounts, depositID);
                break;
            case 9:
                System.exit(0);
            default:
                System.out.println("Invalid Option Number.");
                break;
        }
        } while (selection != 0);
        
    }
    
    public void xCreateChecking(ArrayList<Account> accounts, int iD, double intRate, Balance balance)
    {
        CheckingAccount newAccount = new CheckingAccount(iD, intRate, balance);
        accounts.add(newAccount);
        String info = "Checking Account Created\n" +
                      "_____________________\n" +
                      "Account ID: " + iD + "\n" +
                      "Interest Rate: " + intRate + "\n" +
                      "Balance: " + balance.getBalance() + "\n";
        System.out.println(info);
    }
    
    public void xCreateSavings(ArrayList<Account> accounts, int iD, double intRate, Balance balance)
    {
        SavingsAccount newAccount = new SavingsAccount(iD, intRate, balance);
        accounts.add(newAccount);
        String info = "Savings Account Created\n" +
                      "_____________________\n" +
                      "Account ID: " + iD + "\n" +
                      "Interest Rate: " + intRate + "\n" +
                      "Balance: " + balance.getBalance() + "\n";
        System.out.println(info);
    }
    
    public void xDeleteAccount(ArrayList<Account> accounts, int iD)
    {
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            System.out.println(iD + " " + accounts.get(i).getId());
            if(iD == accounts.get(i).getId())
            {
                accounts.remove(i);
                String removed = "Account has been deleted. \n";
                System.out.println(removed);
                return;
            }
        }
        System.out.println("This account does not exist.");
        
    }
    
    public void xViewSpecific(ArrayList<Account> accounts, int iD)
    {
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            if(iD == accounts.get(i).getId())
            {
                double intRate = accounts.get(i).getInterestRate();
                Balance balance = accounts.get(i).bBalance;
                String info = ("Account ID: " + accounts.get(i).getId() + "\n" +
                               "Interest Rate: " + intRate + "\n" +
                               "Balance: " + balance.getBalance() + "\n");
                System.out.println(info);
                return;
            }
            else
                return;
        }
        System.out.println("This account does not exist.");
    }
    
    public void xViewAll(ArrayList<Account> accounts)
    {
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            double intRate = accounts.get(i).getInterestRate();
            Balance balance = accounts.get(i).bBalance;
            String info = ("Account ID: " + accounts.get(i).getId() + "\n" +
                           "Interest Rate: " + intRate + "\n" +
                           "Balance: " + balance.getBalance() + "\n");
            System.out.println(info);
        }
        
    }
    
    public void xWriteCheck(ArrayList<Account> accounts, int iD)
    {
        Scanner checkAmount = new Scanner(System.in);
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            if(iD == accounts.get(i).getId())
            {
                System.out.println("Please enter Check Amount: ");
                double amount = checkAmount.nextDouble();
                accounts.get(i).withdraw(amount);
                System.out.println("New Balance is " + accounts.get(i).bBalance.getBalance());
            }
            else
            {
                System.out.println("Account does not exist.");
                return;
            }
        }
        System.out.println("There are no accounts.");
    }
    
    public void xWithdraw(ArrayList<Account> accounts, int iD)
    {
        Scanner withdrawAmount = new Scanner(System.in);
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            if(iD == accounts.get(i).getId())
            {
                System.out.println("Please enter Check Amount: ");
                double amount = withdrawAmount.nextDouble();
                accounts.get(i).withdraw(amount);
                System.out.println("New Balance is " + accounts.get(i).bBalance.getBalance());
            }
            else
            {
                System.out.println("Account does not exist.");
                return;
            }
        }
        System.out.println("There are no accounts.");
    }
    
    public void xDeposit(ArrayList<Account> accounts, int iD)
    {
        Scanner depositAmount = new Scanner(System.in);
        int i;
        for(i = 0; i <accounts.size(); i++)
        {
            if(iD == accounts.get(i).getId())
            {
                System.out.println("Please enter Check Amount: ");
                double amount = depositAmount.nextDouble();
                accounts.get(i).deposit(amount);
                System.out.println("New Balance is " + accounts.get(i).bBalance.getBalance());
            }
            else
            {
                System.out.println("Account does not exist.");
                return;
            }  
        }
        System.out.println("There are no accounts.");
    }
}
