
package bankingproject;

/**
 *
 * @author Tony Lim
 */
public class Account 
{
    private int iId;
    private double dInterestRate;
    Balance bBalance;
    public Account(int Id, double InterestRate, Balance Balance)
    {
        iId = Id;
        dInterestRate = InterestRate;
        bBalance = Balance;
    }
    
    public int getId()
    {
        return iId;
    }
    
    public void setId(int Id)
    {
        iId = Id;
    }
    
    public double getInterestRate()
    {
        return dInterestRate;
    }
    
    public void setInterestRate(double InterestRate)
    {
        dInterestRate = InterestRate;
    }
    
    public void deposit(double addToBalance)
    {
        bBalance.setBalance(bBalance.getBalance() + addToBalance);
    }
    
    public void withdraw(double subFromBalance)
    {
        if((bBalance.getBalance() - subFromBalance) < 0)
        {
            System.out.println("Funds are not available.");
        }
        else
        {
            bBalance.setBalance(bBalance.getBalance() - subFromBalance);
        }
    }
    
    public void displayAccount()
    {
        System.out.println("Account ID: " + iId);
        System.out.println("Balance: " + bBalance.getBalance());
        System.out.println("Interest Rate: " + dInterestRate);
    }
}
