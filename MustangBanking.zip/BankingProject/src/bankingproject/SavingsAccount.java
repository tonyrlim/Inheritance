
package bankingproject;

/**
 *
 * @author Tony Lim
 */
public class SavingsAccount extends Account
{
    
    public SavingsAccount(int Id, double InterestRate, Balance Balance) 
    {
        super(Id, InterestRate, Balance);
    }
    public void Withdraw(double amount)
    {
        if((bBalance.getBalance() - amount) < 0)
        {
            System.out.println("Funds are not available.");
        }
        else
        {
            bBalance.setBalance(bBalance.getBalance() - amount);
        }
    }
}
